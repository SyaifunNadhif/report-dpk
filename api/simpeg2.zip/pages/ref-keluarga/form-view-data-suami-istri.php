<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Data<small> Pasangan</small></h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="home-admin.php">Home</a></li>
          <li class="breadcrumb-item active">Data Pasangan</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<?php
	include "dist/koneksi.php";
	$tampilPeg=mysql_query("SELECT
	id_peg,
	(SELECT nama FROM tb_pegawai WHERE id_peg=tb_suamiistri.id_peg) nama_peg,
	nama,
	nik,
	pendidikan,
	pekerjaan,
	status_hub
FROM
	tb_suamiistri");
?>
<section class="content">
    <div class="row">
        <div class="col-md-12">
			<div class="box box-primary">				
				<div class="box-body">							
					<a href="home-admin.php?page=form-master-data-suami-istri" type="button" class="btn btn-primary"><i class="fa fa-plus"></i> Tambah Data Pasangan</a><a href="home-admin.php" type="button" class="btn btn-info float-sm-right"><i class="fa fa-step-backward"></i> Back</a><br /><br />					
					<table id="pasangan" class="table table-bordered table-striped">
						<thead>
							<tr>
								<th>Nama Pegawai</th>
								<th>Nama Pasangan</th>
								<th>NIK Pasangan</th>
								<th>Pendidikan</th>
								<th>Pekerjaan</th>
								<th>Hubungan</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody>
						<?php
							while($peg=mysql_fetch_array($tampilPeg)){
						?>	
							<tr>
								<td><?php echo $peg['nama_peg'];?></td>
								<td><?php echo $peg['nama'];?></td>
								<td><?php echo $peg['nik'];?></td>
								<td><?php echo $peg['pendidikan'];?></td>
								<td><?php echo $peg['pekerjaan'];?></td>
								<td><?php echo $peg['status_hub'];?></td>
								<td class="tools" align="center"><a class="btn btn-primary" href="home-admin.php?page=view-detail-data-pegawai&id_peg=<?=$peg['id_peg'];?>" title="detail"><i class="fa fa-folder-open fa-lg"></i></a>
												<a class="btn btn-warning" href="home-admin.php?page=form-edit-data-pegawai&id_peg=<?=$peg['id_peg'];?>" title="edit"><i class="fa fa-edit fa-lg"></i></a></td>
							</tr>
						<?php
							}
						?>
						</tbody>
					</table>
				</div>
			</div>
        </div>
	</div>
</section>
<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables  & Plugins -->
<script src="plugins/datatables/jquery.dataTables.min.js"></script>
<script src="plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="plugins/jszip/jszip.min.js"></script>
<script src="plugins/pdfmake/pdfmake.min.js"></script>
<script src="plugins/pdfmake/vfs_fonts.js"></script>
<script src="plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.colVis.min.js"></script>

<script>
  $(function () {
    $("#pasangan").DataTable({
      "responsive": true, "lengthChange": false, "autoWidth": false,
      "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
    }).buttons().container().appendTo('#pasangan_wrapper .col-md-6:eq(0)');
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
</script>
