<?php
	if (isset($_GET['id_si'])) {
	$id_si = $_GET['id_si'];
	}
	else {
		die ("Error. No Kode Selected! ");	
	}
	include "dist/koneksi.php";
	$ambilData=mysql_query("SELECT * FROM tb_suamiistri WHERE id_si='$id_si'");
	$hasil=mysql_fetch_array($ambilData);
		$id_si	= $hasil['id_si'];
		$id_peg	= $hasil['id_peg'];
		$nik	= $hasil['nik'];
?>
<section class="content-header">
    <h1>Edit<small>Data Suami Istri <b>#<?=$nik?></b></small></h1>
    <ol class="breadcrumb">
        <li><a href="home-admin.php"><i class="fa fa-dashboard"></i>Dashboard</a></li>
        <li class="active">Edit Data</li>
    </ol>
</section>
<section class="content">
	<div class="row">
		<div class="col-md-12">
			<div class="box box-primary">
				<form action="home-admin.php?page=edit-data-suami-istri&id_si=<?=$id_si?>" class="form-horizontal" method="POST" enctype="multipart/form-data">
					<div class="box-body">
						<div class="form-group">
							<label class="col-sm-3 control-label">NIK</label>
							<div class="col-sm-7">
								<input type="text" name="nik" class="form-control" value="<?=$hasil['nik'];?>" maxlength="16">
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-3 control-label">Nama</label>
							<div class="col-sm-7">
								<input type="text" name="nama" class="form-control" value="<?=$hasil['nama'];?>" maxlength="64">
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-3 control-label">Tempat, Tanggal Lahir</label>
							<div class="col-sm-3">
								<input type="text" name="tmp_lhr" class="form-control" value="<?=$hasil['tmp_lhr'];?>" maxlength="64">
							</div>
							<div class="input-group date form_date col-sm-3" data-date="" data-date-format="yyyy-mm-dd" data-link-field="dtp_input2" data-link-format="yyyy-mm-dd">
								<input type="text" name="tgl_lhr" class="form-control" value="<?=$hasil['tgl_lhr'];?>"><span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
							</div>
						</div>
						<div class="form-group has-feedback">
							<label class="col-sm-3 control-label">Pendidikan</label>
							<div class="col-sm-7">
								<select name="pendidikan" class="form-control">
									<option value="SD" <?php echo ($hasil['pendidikan']=='SD')?"selected":""; ?>>SD
									<option value="SLTP" <?php echo ($hasil['pendidikan']=='SLTP')?"selected":""; ?>>SLTP									
									<option value="SLTA" <?php echo ($hasil['pendidikan']=='SLTA')?"selected":""; ?>>SLTA									
									<option value="D3" <?php echo ($hasil['pendidikan']=='D3')?"selected":""; ?>>D3									
									<option value="S1" <?php echo ($hasil['pendidikan']=='S1')?"selected":""; ?>>S1									
									<option value="S2" <?php echo ($hasil['pendidikan']=='S2')?"selected":""; ?>>S2								
									<option value="S3" <?php echo ($hasil['pendidikan']=='S3')?"selected":""; ?>>S3								
								</select>
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-3 control-label">Pekerjaan</label>
							<div class="col-sm-7">
								<input type="text" name="pekerjaan" class="form-control" value="<?=$hasil['pekerjaan'];?>" maxlength="32">
							</div>
						</div>
						<div class="form-group has-feedback">
							<label class="col-sm-3 control-label">Hubungan</label>
							<div class="col-sm-7">
								<select name="status_hub" class="form-control">
									<option value="Suami" <?php echo ($hasil['status_hub']=='Suami')?"selected":""; ?>>Suami
									<option value="Istri" <?php echo ($hasil['status_hub']=='Istri')?"selected":""; ?>>Istri
								</select>
							</div>
						</div>
						<div class="form-group">
							<div class="col-sm-offset-3 col-sm-7">
								<button type="submit" name="edit" value="edit" class="btn btn-danger">Edit</button>
								<a href="home-admin.php?page=view-detail-data-pegawai&id_peg=<?=$id_peg?>" type="button" class="btn btn-default">Cancel</a>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</section>
<!-- datepicker -->
<script type="text/javascript" src="plugins/datepicker/jquery/jquery-1.8.3.min.js" charset="UTF-8"></script>
<script type="text/javascript" src="plugins/datepicker/js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
<script type="text/javascript" src="plugins/datepicker/js/locales/bootstrap-datetimepicker.id.js" charset="UTF-8"></script>
<script type="text/javascript">
	 $('.form_date').datetimepicker({
			language:  'id',
			weekStart: 1,
			todayBtn:  1,
	  autoclose: 1,
	  todayHighlight: 1,
	  startView: 2,
	  minView: 2,
	  forceParse: 0
		});
</script>