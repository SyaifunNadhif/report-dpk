<?php
	if (isset($_GET['id_mutasi'])) {
	$id_mutasi = $_GET['id_mutasi'];
	}
	else {
		die ("Error. No Kode Selected! ");	
	}
	include "dist/koneksi.php";
	$ambilData=mysql_query("SELECT * FROM tb_mutasi WHERE id_mutasi='$id_mutasi'");
	$hasil=mysql_fetch_array($ambilData);
		$id_mutasi	= $hasil['id_mutasi'];
		$id_peg	= $hasil['id_peg'];
	
	$ambilPeg=mysql_query("SELECT * FROM tb_pegawai WHERE id_peg='$id_peg'");
	$peg=mysql_fetch_array($ambilPeg);
		$nip	= $peg['nip'];
?>
<section class="content-header">
    <h1>Edit<small>Data Mutasi <b>#<?=$nip?></b></small></h1>
    <ol class="breadcrumb">
        <li><a href="home-admin.php"><i class="fa fa-dashboard"></i>Dashboard</a></li>
        <li class="active">Edit Data</li>
    </ol>
</section>
<section class="content">
	<div class="row">
		<div class="col-md-12">
			<div class="box box-primary">
				<form action="home-admin.php?page=edit-data-mutasi&id_mutasi=<?=$id_mutasi?>" class="form-horizontal" method="POST" enctype="multipart/form-data">
					<div class="box-body">
						<div class="form-group has-feedback">
							<label class="col-sm-3 control-label">Jenis Mutasi</label>
							<div class="col-sm-7">
								<select name="jns_mutasi" class="form-control select2">
									<option value="Masuk" <?php echo ($hasil['jns_mutasi']=='Masuk')?"selected":""; ?>>Masuk
									<option value="Keluar" <?php echo ($hasil['jns_mutasi']=='Keluar')?"selected":""; ?>>Keluar									
									<option value="Pindah Antar Instansi" <?php echo ($hasil['jns_mutasi']=='Pindah Antar Instansi')?"selected":""; ?>>Pindah Antar Instansi								
									<option value="Pensiun" <?php echo ($hasil['jns_mutasi']=='Pensiun')?"selected":""; ?>>Pensiun									
									<option value="Wafat" <?php echo ($hasil['jns_mutasi']=='Wafat')?"selected":""; ?>>Wafat									
									<option value="Kenaikan Pangkat" <?php echo ($hasil['jns_mutasi']=='Kenaikan Pangkat')?"selected":""; ?>>Kenaikan Pangkat								
								</select>
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-3 control-label">Tanggal</label>
							<div class="col-sm-4">
								<div class="input-group date form_date" data-date="" data-date-format="yyyy-mm-dd" data-link-field="dtp_input2" data-link-format="yyyy-mm-dd">
									<input type="text" name="tgl_mutasi" value="<?=$hasil['tgl_mutasi'];?>" class="form-control"><span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
								</div>
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-3 control-label">No. SK</label>
							<div class="col-sm-4">
								<input type="text" name="no_mutasi" value="<?=$hasil['no_mutasi'];?>" class="form-control" maxlength="32">
							</div>
						</div>
						<div class="form-group">
							<div class="col-sm-offset-3 col-sm-7">
								<button type="submit" name="edit" value="edit" class="btn btn-danger">Edit</button>
								<a href="home-admin.php?page=view-detail-data-pegawai&id_peg=<?=$id_peg?>" type="button" class="btn btn-default">Cancel</a>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</section>
<!-- datepicker -->
<script type="text/javascript" src="plugins/datepicker/jquery/jquery-1.8.3.min.js" charset="UTF-8"></script>
<script type="text/javascript" src="plugins/datepicker/js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
<script type="text/javascript" src="plugins/datepicker/js/locales/bootstrap-datetimepicker.id.js" charset="UTF-8"></script>
<script type="text/javascript">
	 $('.form_date').datetimepicker({
			language:  'id',
			weekStart: 1,
			todayBtn:  1,
	  autoclose: 1,
	  todayHighlight: 1,
	  startView: 2,
	  minView: 2,
	  forceParse: 0
		});
	$(function () {
		//Initialize Select2 Elements
		$(".select2").select2();
	});
</script>