<section class="content-header">
    <h1>Report<small>Daftar Urut Kepangkatan</small></h1>
    <ol class="breadcrumb">
        <li><a href="home-admin.php"><i class="fa fa-dashboard"></i>Dashboard</a></li>
        <li class="active">Daftar Urut</li>
    </ol>
</section>
<section class="content">
	<div class="row">
		<div class="col-md-12">	
			<div class="box box-primary">
				<div class="box-body" align="right">						
					<a type="button" href="./pages/report/print-daftar-urut-kepangkatan.php" target="_blank" class="btn btn-default bg-orange"><i class="fa fa-print"></i> Print</a>						
				</div>
				<div class="box-body">
					<h4 class="title" align="center">DAFTAR URUT KEPANGKATAN PEGAWAI NEGERI SIPIL</h4>
					<h5 class="title" align="center">BPR BKK JATENG TAHUN <?php echo date ("Y");?></h5>
					<table class="col-sm-12 table table-bordered table-hover">
						<thead>
							<tr>
								<th rowspan="2">No</th>
								<th colspan="2">NAMA</th>
								<th rowspan="2">NIP</th>
								<th colspan="2">PKT TERAKHIR</th>
								<th colspan="2">JABATAN</th>
								<th rowspan="2">ESLON</th>
								<th colspan="2">MK GOL</th>
								<th colspan="3">LATIHAN JABATAN</th>
								<th colspan="3">PEND AKHIR</th>
								<th rowspan="2">KET</th>
							</tr>
							<tr>
								<th colspan="2">TTL</th>
								<th>GOL/RUANG</th>
								<th>TMT</th>
								<th>NAMA</th>
								<th>TMT</th>
								<th>THN</th>
								<th>BLN</th>
								<th>NAMA</th>
								<th>THN</th>
								<th>JML JAM</th>
								<th>ASAL</th>
								<th>T.LLS</th>
								<th>TK.IJAZAH</th>
							</tr>
							<tr>
								<th>1</th>
								<th colspan="2">2</th>
								<th>3</th>
								<th>4</th>
								<th>5</th>
								<th>6</th>
								<th>7</th>
								<th>8</th>
								<th>9</th>
								<th>10</th>
								<th>11</th>
								<th>12</th>
								<th>13</th>
								<th>14</th>
								<th>15</th>
								<th>16</th>
								<th>17</th>
							</tr>
						</thead>
						<tbody>
							<?php
							include "dist/koneksi.php";
							$no=0;
							$idPeg=mysql_query("SELECT * FROM tb_pegawai WHERE status_kepeg='PNS' ORDER BY urut_pangkat DESC");
							while($peg=mysql_fetch_array($idPeg)){
							$no++
							?>
							<tr>
								<td><?=$no;?></td>
								<td colspan="2"><?php echo $peg['nama']; ?><br /><?php echo $peg['tempat_lhr']; ?>, <?php echo $peg['tgl_lhr']; ?></td>
								<td><?php echo $peg['nip']; ?></td>
								<td><?php
									$idPan=mysql_query("SELECT * FROM tb_pangkat WHERE (id_peg='$peg[id_peg]' AND status_pan='Aktif')");
									$hpan=mysql_fetch_array($idPan);
								?>
								<?php echo $hpan['pangkat']; ?><br /><?php echo $hpan['gol']; ?></td>
								<td><?php echo $hpan['tmt_pangkat']; ?></td>
								<td><?php
									$idJab=mysql_query("SELECT * FROM tb_jabatan WHERE (id_peg='$peg[id_peg]' AND status_jab='Aktif')");
									$hjab=mysql_fetch_array($idJab);
								?>
								<?php echo $hjab['jabatan']; ?></td>
								<td><?php echo $hjab['tmt_jabatan']; ?></td>
								<td><?php echo $hjab['eselon']; ?></td>
								<td><?php
									$tgl_sk	= new DateTime($hpan['tgl_sk']);
									$today	= new DateTime();										
									$selisih	= $today->diff($tgl_sk);										
										echo $selisih->y;
									?>											
								</td>
								<td><?php echo $selisih->m;?></td>
								<td><?php
									$idLatjab=mysql_query("SELECT * FROM tb_lat_jabatan WHERE id_peg='$peg[id_peg]'");
									$hljab=mysql_fetch_array($idLatjab);
								?>
								<?php echo $hljab['nama_pelatih']; ?></td>
								<td><?php echo $hljab['tahun_lat']; ?></td>
								<td><?php echo $hljab['jml_jam']; ?></td>
								<td><?php
									$idSek=mysql_query("SELECT * FROM tb_sekolah WHERE (id_peg='$peg[id_peg]' AND status='Akhir')");
									$hsek=mysql_fetch_array($idSek);
								?>
								<?php echo $hsek['nama_sekolah']; ?>
								</td>
								<td><?php echo $hsek['tgl_ijazah']; ?></td>
								<td><?php echo $hsek['tingkat']; ?></td>
								<td><?php echo $peg['status_kepeg']; ?></td>
							</tr>
							<?php
							}		
							?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</section>