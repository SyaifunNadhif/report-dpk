<section class="content-header">
    <h1>Report<small>Keadaan Pegawai</small></h1>
    <ol class="breadcrumb">
        <li><a href="home-admin.php"><i class="fa fa-dashboard"></i>Dashboard</a></li>
        <li class="active">Keadaan Pegawai</li>
    </ol>
</section>
<?php
include "dist/koneksi.php";
?>
<section class="content">
	<div class="row">
		<div class="col-md-12">	
			<div class="box box-primary">
				<div class="box-body" align="right">						
					<a type="button" href="./pages/report/print-keadaan-pegawai.php" target="_blank" class="btn btn-default bg-orange"><i class="fa fa-print"></i> Print</a>						
				</div>
				<div class="box-body">
					<h4 class="title" align="center">LAPORAN BULANAN KEADAAN PEGAWAI</h4>
					<h5 class="title" align="center">BPR BKK JATENG</h5><br />					
					<table border="0">
						<tr>
							<th width="120">SATUAN KERJA</th>
							<th>: BPR BKK JATENG</th>
						</tr>
						<tr>
							<th>PERIODE</th>
							<th>: BULAN <?php echo date("m");?> TAHUN <?php echo date("Y");?></th>
						</tr>
					</table>
					<br />
					<table class="col-sm-12 table table-bordered table-hover">
						<thead>
							<tr>
								<th rowspan="2">No</th>
								<th rowspan="2">JENIS LAPORAN</th>
								<th colspan="5">USIA</th>
								<th rowspan="2">JML</th>
								<th rowspan="2">KET</th>
							</tr>
							<tr>
								<th>0 s.d. 25</th>
								<th>>25 s.d. 35</th>
								<th>>35 s.d. 45</th>
								<th>>45 s.d. 55</th>
								<th>>55</th>
							</tr>
							<tr>
								<th>1</th>
								<th>2</th>
								<th>3</th>
								<th>4</th>
								<th>5</th>
								<th>6</th>
								<th>7</th>
								<th>8</th>
								<th>9</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>1</td>
								<td>JUMLAH PEGAWAI</td>

							</tr>
							<tr>
								<td></td>
								<td>- LAKI-LAKI</td>
								<td><?php
									$pegL1=mysql_query("SELECT id_peg, TIMESTAMPDIFF(YEAR, tgl_lhr, CURDATE()) AS umur FROM tb_pegawai WHERE jk='Laki-laki' HAVING umur<=25 ");
									$jL1=mysql_num_rows($pegL1);
										if ($jL1==0){
										echo "-";
										}
										else{
										echo $jL1;
										}
									?>				
								</td>
								<td><?php
									$pegL2=mysql_query("SELECT id_peg, TIMESTAMPDIFF(YEAR, tgl_lhr, CURDATE()) AS umur FROM tb_pegawai WHERE jk='Laki-laki' HAVING umur >25 AND umur <=35 ");
									$jL2=mysql_num_rows($pegL2);	
										if ($jL2==0){
										echo "-";
										}
										else{
										echo $jL2;
										}
									?>				
								</td>
								<td><?php
									$pegL3=mysql_query("SELECT id_peg, TIMESTAMPDIFF(YEAR, tgl_lhr, CURDATE()) AS umur FROM tb_pegawai WHERE jk='Laki-laki' HAVING umur >35 AND umur <=45 ");
									$jL3=mysql_num_rows($pegL3);	
										if ($jL3==0){
										echo "-";
										}
										else{
										echo $jL3;
										}
									?>				
								</td>
								<td><?php
									$pegL4=mysql_query("SELECT id_peg, TIMESTAMPDIFF(YEAR, tgl_lhr, CURDATE()) AS umur FROM tb_pegawai WHERE jk='Laki-laki' HAVING umur >45 AND umur <=55 ");
									$jL4=mysql_num_rows($pegL4);	
										if ($jL4==0){
										echo "-";
										}
										else{
										echo $jL4;
										}
									?>				
								</td>
								<td><?php
									$pegL=mysql_query("SELECT id_peg, TIMESTAMPDIFF(YEAR, tgl_lhr, CURDATE()) AS umur FROM tb_pegawai WHERE jk='Laki-laki' HAVING umur >55");
									$jL=mysql_num_rows($pegL);	
										if ($jL==0){
										echo "-";
										}
										else{
										echo $jL;
										}
									?>				
								</td>
								<td><?php
									$pegL=mysql_query("SELECT id_peg, TIMESTAMPDIFF(YEAR, tgl_lhr, CURDATE()) AS umur FROM tb_pegawai WHERE jk='Laki-laki'");
									$jL=mysql_num_rows($pegL);	
										if ($jL==0){
										echo "-";
										}
										else{
										echo $jL;
										}
									?>	
								</td>
								<td></td>
							</tr>
							<tr>
								<td></td>
								<td>- PEREMPUAN</td>
								<td><?php
									$pegL1=mysql_query("SELECT id_peg, TIMESTAMPDIFF(YEAR, tgl_lhr, CURDATE()) AS umur FROM tb_pegawai WHERE jk='Perempuan' HAVING umur<=25 ");
									$jL1=mysql_num_rows($pegL1);
										if ($jL1==0){
										echo "-";
										}
										else{
										echo $jL1;
										}
									?>				
								</td>
								<td><?php
									$pegL2=mysql_query("SELECT id_peg, TIMESTAMPDIFF(YEAR, tgl_lhr, CURDATE()) AS umur FROM tb_pegawai WHERE jk='Perempuan' HAVING umur >25 AND umur <=35 ");
									$jL2=mysql_num_rows($pegL2);	
										if ($jL2==0){
										echo "-";
										}
										else{
										echo $jL2;
										}
									?>				
								</td>
								<td><?php
									$pegL3=mysql_query("SELECT id_peg, TIMESTAMPDIFF(YEAR, tgl_lhr, CURDATE()) AS umur FROM tb_pegawai WHERE jk='Perempuan' HAVING umur >35 AND umur <=45 ");
									$jL3=mysql_num_rows($pegL3);	
										if ($jL3==0){
										echo "-";
										}
										else{
										echo $jL3;
										}
									?>				
								</td>
								<td><?php
									$pegL4=mysql_query("SELECT id_peg, TIMESTAMPDIFF(YEAR, tgl_lhr, CURDATE()) AS umur FROM tb_pegawai WHERE jk='Perempuan' HAVING umur >45 AND umur <=55 ");
									$jL4=mysql_num_rows($pegL4);	
										if ($jL4==0){
										echo "-";
										}
										else{
										echo $jL4;
										}
									?>				
								</td>
								<td><?php
									$pegL=mysql_query("SELECT id_peg, TIMESTAMPDIFF(YEAR, tgl_lhr, CURDATE()) AS umur FROM tb_pegawai WHERE jk='Perempuan' HAVING umur >55");
									$jL=mysql_num_rows($pegL);	
										if ($jL==0){
										echo "-";
										}
										else{
										echo $jL;
										}
									?>				
								</td>
								<td><?php
									$pegL=mysql_query("SELECT id_peg, TIMESTAMPDIFF(YEAR, tgl_lhr, CURDATE()) AS umur FROM tb_pegawai WHERE jk='Perempuan'");
									$jL=mysql_num_rows($pegL);	
										if ($jL==0){
										echo "-";
										}
										else{
										echo $jL;
										}
									?>	
								</td>
								<td></td>
							</tr>
							<tr>
								<td>2</td>
								<td>JENIS PENDIDIKAN</td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<td></td>
								<td>- SD/Sederajat</td>
								<td><?php
									$sd1=mysql_query("SELECT a.id_peg, TIMESTAMPDIFF(YEAR, tgl_lhr, CURDATE()) AS umur FROM tb_sekolah a, tb_pegawai b WHERE a.id_peg=b.id_peg AND status='Akhir' AND tingkat='SD' HAVING umur<=25");
									$jsd1=mysql_num_rows($sd1);
										if ($jsd1==0){
										echo "-";
										}
										else{
										echo $jsd1;
										}
									?>
								</td>
								<td><?php
									$sd2=mysql_query("SELECT a.id_peg, TIMESTAMPDIFF(YEAR, tgl_lhr, CURDATE()) AS umur FROM tb_sekolah a, tb_pegawai b WHERE a.id_peg=b.id_peg AND status='Akhir' AND tingkat='SD' HAVING umur >25 AND umur <=35");
									$jsd2=mysql_num_rows($sd2);
										if ($jsd2==0){
										echo "-";
										}
										else{
										echo $jsd2;
										}
									?>
								</td>
								<td><?php
									$sd3=mysql_query("SELECT a.id_peg, TIMESTAMPDIFF(YEAR, tgl_lhr, CURDATE()) AS umur FROM tb_sekolah a, tb_pegawai b WHERE a.id_peg=b.id_peg AND status='Akhir' AND tingkat='SD' HAVING umur >35 AND umur <=45");
									$jsd3=mysql_num_rows($sd3);
										if ($jsd3==0){
										echo "-";
										}
										else{
										echo $jsd3;
										}
									?>
								</td>
								<td><?php
									$sd4=mysql_query("SELECT a.id_peg, TIMESTAMPDIFF(YEAR, tgl_lhr, CURDATE()) AS umur FROM tb_sekolah a, tb_pegawai b WHERE a.id_peg=b.id_peg AND status='Akhir' AND tingkat='SD' HAVING umur >45 AND umur <=55");
									$jsd4=mysql_num_rows($sd4);
										if ($jsd4==0){
										echo "-";
										}
										else{
										echo $jsd4;
										}
									?>
								</td>
								<td><?php
									$sd=mysql_query("SELECT a.id_peg, TIMESTAMPDIFF(YEAR, tgl_lhr, CURDATE()) AS umur FROM tb_sekolah a, tb_pegawai b WHERE a.id_peg=b.id_peg AND status='Akhir' AND tingkat='SD' HAVING umur >55");
									$jsd=mysql_num_rows($sd);
										if ($jsd==0){
										echo "-";
										}
										else{
										echo $jsd;
										}
									?>
								</td>
								<td><?php
									$sd=mysql_query("SELECT a.id_peg, TIMESTAMPDIFF(YEAR, tgl_lhr, CURDATE()) AS umur FROM tb_sekolah a, tb_pegawai b WHERE a.id_peg=b.id_peg AND status='Akhir' AND tingkat='SD'");
									$jsd=mysql_num_rows($sd);
										if ($jsd==0){
										echo "-";
										}
										else{
										echo $jsd;
										}
									?></td>
								<td></td>
							</tr>
							<tr>
								<td></td>
								<td>- SMP/Sederajat</td>
								<td><?php
									$smp1=mysql_query("SELECT * FROM tb_sekolah WHERE status='Akhir' AND (tingkat LIKE 'SMP%' OR tingkat LIKE 'MTS%') AND gol LIKE 'I/%'");
									$jsmp1=mysql_num_rows($smp1);
										if ($jsmp1==0){
										echo "-";
										}
										else{
										echo $jsmp1;
										}
									?>
								</td>
								<td><?php
									$smp2=mysql_query("SELECT * FROM tb_sekolah WHERE status='Akhir' AND (tingkat LIKE 'SMP%' OR tingkat LIKE 'MTS%') AND gol LIKE 'II/%'");
									$jsmp2=mysql_num_rows($smp2);
										if ($jsmp2==0){
										echo "-";
										}
										else{
										echo $jsmp2;
										}
									?>
								</td>
								<td><?php
									$smp3=mysql_query("SELECT * FROM tb_sekolah WHERE status='Akhir' AND (tingkat LIKE 'SMP%' OR tingkat LIKE 'MTS%') AND gol LIKE 'III/%'");
									$jsmp3=mysql_num_rows($smp3);
										if ($jsmp3==0){
										echo "-";
										}
										else{
										echo $jsmp3;
										}
									?>
								</td>
								<td><?php
									$smp4=mysql_query("SELECT * FROM tb_sekolah WHERE status='Akhir' AND (tingkat LIKE 'SMP%' OR tingkat LIKE 'MTS%') AND gol LIKE 'IV/%'");
									$jsmp4=mysql_num_rows($smp4);
										if ($jsmp4==0){
										echo "-";
										}
										else{
										echo $jsmp4;
										}
									?>
								</td>
								<td><?php
									$smp=mysql_query("SELECT * FROM tb_sekolah WHERE status='Akhir' AND (tingkat LIKE 'SMP%' OR tingkat LIKE 'MTS%')");
									$jsmp=mysql_num_rows($smp);
										if ($jsmp==0){
										echo "-";
										}
										else{
										echo $jsmp;
										}
									?>
								</td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<td></td>
								<td>- SMA/Sederajat</td>
								<td><?php
									$sma1=mysql_query("SELECT * FROM tb_sekolah WHERE status='Akhir' AND (tingkat LIKE 'SMK%' OR tingkat LIKE 'SMK%' OR tingkat LIKE 'MA%') AND gol LIKE 'I/%'");
									$jsma1=mysql_num_rows($sma1);
										if ($jsma1==0){
										echo "-";
										}
										else{
										echo $jsma1;
										}
									?>
								</td>
								<td><?php
									$sma2=mysql_query("SELECT * FROM tb_sekolah WHERE status='Akhir' AND (tingkat LIKE 'SMK%' OR tingkat LIKE 'SMK%' OR tingkat LIKE 'MA%') AND gol LIKE 'II/%'");
									$jsma2=mysql_num_rows($sma2);
										if ($jsma2==0){
										echo "-";
										}
										else{
										echo $jsma2;
										}
									?>
								</td>
								<td><?php
									$sma3=mysql_query("SELECT * FROM tb_sekolah WHERE status='Akhir' AND (tingkat LIKE 'SMK%' OR tingkat LIKE 'SMK%' OR tingkat LIKE 'MA%') AND gol LIKE 'III/%'");
									$jsma3=mysql_num_rows($sma3);
										if ($jsma3==0){
										echo "-";
										}
										else{
										echo $jsma3;
										}
									?>
								</td>
								<td><?php
									$sma4=mysql_query("SELECT * FROM tb_sekolah WHERE status='Akhir' AND (tingkat LIKE 'SMK%' OR tingkat LIKE 'SMK%' OR tingkat LIKE 'MA%') AND gol LIKE 'IV/%'");
									$jsma4=mysql_num_rows($sma4);
										if ($jsma4==0){
										echo "-";
										}
										else{
										echo $jsma4;
										}
									?>
								</td>
								<td><?php
									$sma=mysql_query("SELECT * FROM tb_sekolah WHERE status='Akhir' AND (tingkat LIKE 'SMK%' OR tingkat LIKE 'SMK%' OR tingkat LIKE 'MA%')");
									$jsma=mysql_num_rows($sma);
										if ($jsma==0){
										echo "-";
										}
										else{
										echo $jsma;
										}
									?>
								</td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<td></td>
								<td>- D2/D3</td>
								<td><?php
									$d1=mysql_query("SELECT * FROM tb_sekolah WHERE status='Akhir' AND (tingkat LIKE 'D2%' OR tingkat LIKE 'D3%') AND gol LIKE 'I/%'");
									$jd1=mysql_num_rows($d1);
										if ($jd1==0){
										echo "-";
										}
										else{
										echo $jd1;
										}
									?>
								</td>
								<td><?php
									$d2=mysql_query("SELECT * FROM tb_sekolah WHERE status='Akhir' AND (tingkat LIKE 'D2%' OR tingkat LIKE 'D3%') AND gol LIKE 'II/%'");
									$jd2=mysql_num_rows($d2);
										if ($jd2==0){
										echo "-";
										}
										else{
										echo $jd2;
										}
									?>
								</td>
								<td><?php
									$d3=mysql_query("SELECT * FROM tb_sekolah WHERE status='Akhir' AND (tingkat LIKE 'D2%' OR tingkat LIKE 'D3%') AND gol LIKE 'III/%'");
									$jd3=mysql_num_rows($d3);
										if ($jd3==0){
										echo "-";
										}
										else{
										echo $jd3;
										}
									?>
								</td>
								<td><?php
									$d4=mysql_query("SELECT * FROM tb_sekolah WHERE status='Akhir' AND (tingkat LIKE 'D2%' OR tingkat LIKE 'D3%') AND gol LIKE 'IV/%'");
									$jd4=mysql_num_rows($d4);
										if ($jd4==0){
										echo "-";
										}
										else{
										echo $jd4;
										}
									?>
								</td>
								<td><?php
									$d=mysql_query("SELECT * FROM tb_sekolah WHERE status='Akhir' AND (tingkat LIKE 'D2%' OR tingkat LIKE 'D3%')");
									$jd=mysql_num_rows($d);
										if ($jd==0){
										echo "-";
										}
										else{
										echo $jd;
										}
									?>
								</td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<td></td>
								<td>- S1/D4</td>
								<td><?php
									$s11=mysql_query("SELECT * FROM tb_sekolah WHERE status='Akhir' AND (tingkat LIKE 'S1%' OR tingkat LIKE 'D4%') AND gol LIKE 'I/%'");
									$js11=mysql_num_rows($s11);
										if ($js11==0){
										echo "-";
										}
										else{
										echo $js11;
										}
									?>
								</td>
								<td><?php
									$s12=mysql_query("SELECT * FROM tb_sekolah WHERE status='Akhir' AND (tingkat LIKE 'S1%' OR tingkat LIKE 'D4%') AND gol LIKE 'II/%'");
									$js12=mysql_num_rows($s12);
										if ($js12==0){
										echo "-";
										}
										else{
										echo $js12;
										}
									?>
								</td>
								<td><?php
									$s13=mysql_query("SELECT * FROM tb_sekolah WHERE status='Akhir' AND (tingkat LIKE 'S1%' OR tingkat LIKE 'D4%') AND gol LIKE 'III/%'");
									$js13=mysql_num_rows($s13);
										if ($js13==0){
										echo "-";
										}
										else{
										echo $js13;
										}
									?>
								</td>
								<td><?php
									$s14=mysql_query("SELECT * FROM tb_sekolah WHERE status='Akhir' AND (tingkat LIKE 'S1%' OR tingkat LIKE 'D4%') AND gol LIKE 'IV/%'");
									$js14=mysql_num_rows($s14);
										if ($js14==0){
										echo "-";
										}
										else{
										echo $js14;
										}
									?>
								</td>
								<td><?php
									$s1=mysql_query("SELECT * FROM tb_sekolah WHERE status='Akhir' AND (tingkat LIKE 'S1%' OR tingkat LIKE 'D4%')");
									$js1=mysql_num_rows($s1);
										if ($js1==0){
										echo "-";
										}
										else{
										echo $js1;
										}
									?>
								</td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<td></td>
								<td>- S2/S3</td>
								<td><?php
									$s21=mysql_query("SELECT * FROM tb_sekolah WHERE status='Akhir' AND (tingkat LIKE 'S2%' OR tingkat LIKE 'S3%') AND gol LIKE 'I/%'");
									$js21=mysql_num_rows($s21);
										if ($js21==0){
										echo "-";
										}
										else{
										echo $js21;
										}
									?>
								</td>
								<td><?php
									$s22=mysql_query("SELECT * FROM tb_sekolah WHERE status='Akhir' AND (tingkat LIKE 'S2%' OR tingkat LIKE 'S3%') AND gol LIKE 'II/%'");
									$js22=mysql_num_rows($s22);
										if ($js22==0){
										echo "-";
										}
										else{
										echo $js22;
										}
									?>
								</td>
								<td><?php
									$s23=mysql_query("SELECT * FROM tb_sekolah WHERE status='Akhir' AND (tingkat LIKE 'S2%' OR tingkat LIKE 'S3%') AND gol LIKE 'III/%'");
									$js23=mysql_num_rows($s23);
										if ($js23==0){
										echo "-";
										}
										else{
										echo $js23;
										}
									?>
								</td>
								<td><?php
									$s24=mysql_query("SELECT * FROM tb_sekolah WHERE status='Akhir' AND (tingkat LIKE 'S2%' OR tingkat LIKE 'S3%') AND gol LIKE 'IV/%'");
									$js24=mysql_num_rows($s24);
										if ($js24==0){
										echo "-";
										}
										else{
										echo $js24;
										}
									?>
								</td>
								<td><?php
									$s2=mysql_query("SELECT * FROM tb_sekolah WHERE status='Akhir' AND (tingkat LIKE 'S2%' OR tingkat LIKE 'S3%')");
									$js2=mysql_num_rows($s2);
										if ($js2==0){
										echo "-";
										}
										else{
										echo $js2;
										}
									?>
								</td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<td>3</td>
								<td>MUTASI PEGAWAI</td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
							<?php
							$skrg=date("Y-m");
							?>
							<tr>
								<td></td>
								<td>- MASUK</td>
								<td><?php
									$mg1=mysql_query("SELECT * FROM tb_mutasi WHERE jns_mutasi='Masuk' AND tgl_mutasi LIKE '$skrg%' AND gol LIKE 'I/%'");
									$jmg1=mysql_num_rows($mg1);
										if ($jmg1==0){
										echo "-";
										}
										else{
										echo $jmg1;
										}
									?>
								</td>
								<td><?php
									$mg2=mysql_query("SELECT * FROM tb_mutasi WHERE jns_mutasi='Masuk' AND tgl_mutasi LIKE '$skrg%' AND gol LIKE 'II/%'");
									$jmg2=mysql_num_rows($mg2);
										if ($jmg2==0){
										echo "-";
										}
										else{
										echo $jmg2;
										}
									?>
								</td>
								<td><?php
									$mg3=mysql_query("SELECT * FROM tb_mutasi WHERE jns_mutasi='Masuk' AND tgl_mutasi LIKE '$skrg%' AND gol LIKE 'III/%'");
									$jmg3=mysql_num_rows($mg3);
										if ($jmg3==0){
										echo "-";
										}
										else{
										echo $jmg3;
										}
									?>
								</td>
								<td><?php
									$mg4=mysql_query("SELECT * FROM tb_mutasi WHERE jns_mutasi='Masuk' AND tgl_mutasi LIKE '$skrg%' AND gol LIKE 'IV/%'");
									$jmg4=mysql_num_rows($mg4);
										if ($jmg4==0){
										echo "-";
										}
										else{
										echo $jmg4;
										}
									?>
								</td>
								<td><?php
									$mg=mysql_query("SELECT * FROM tb_mutasi WHERE jns_mutasi='Masuk' AND tgl_mutasi LIKE '$skrg%'");
									$jmg=mysql_num_rows($mg);
										if ($jmg==0){
										echo "-";
										}
										else{
										echo $jmg;
										}
									?>
								</td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<td></td>
								<td>- KELUAR</td>
								<td><?php
									$mkg1=mysql_query("SELECT * FROM tb_mutasi WHERE jns_mutasi='Keluar' AND tgl_mutasi LIKE '$skrg%' AND gol LIKE 'I/%'");
									$jmkg1=mysql_num_rows($mkg1);
										if ($jmkg1==0){
										echo "-";
										}
										else{
										echo $jmkg1;
										}
									?>
								</td>
								<td><?php
									$mkg2=mysql_query("SELECT * FROM tb_mutasi WHERE jns_mutasi='Keluar' AND tgl_mutasi LIKE '$skrg%' AND gol LIKE 'II/%'");
									$jmkg2=mysql_num_rows($mkg2);
										if ($jmkg2==0){
										echo "-";
										}
										else{
										echo $jmkg2;
										}
									?>
								</td>
								<td><?php
									$mkg3=mysql_query("SELECT * FROM tb_mutasi WHERE jns_mutasi='Keluar' AND tgl_mutasi LIKE '$skrg%' AND gol LIKE 'III/%'");
									$jmkg3=mysql_num_rows($mkg3);
										if ($jmkg3==0){
										echo "-";
										}
										else{
										echo $jmkg3;
										}
									?>
								</td>
								<td><?php
									$mkg4=mysql_query("SELECT * FROM tb_mutasi WHERE jns_mutasi='Keluar' AND tgl_mutasi LIKE '$skrg%' AND gol LIKE 'IV/%'");
									$jmkg4=mysql_num_rows($mkg4);
										if ($jmkg4==0){
										echo "-";
										}
										else{
										echo $jmkg4;
										}
									?>
								</td>
								<td><?php
									$mkg=mysql_query("SELECT * FROM tb_mutasi WHERE jns_mutasi='Keluar' AND tgl_mutasi LIKE '$skrg%'");
									$jmkg=mysql_num_rows($mkg);
										if ($jmkg==0){
										echo "-";
										}
										else{
										echo $jmkg;
										}
									?>
								</td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<td></td>
								<td>- PINDAH ANTAR INSTANSI</td>
								<td><?php
									$mpg1=mysql_query("SELECT * FROM tb_mutasi WHERE jns_mutasi='Pindah Antar Instansi' AND tgl_mutasi LIKE '$skrg%' AND gol LIKE 'I/%'");
									$jmpg1=mysql_num_rows($mpg1);
										if ($jmpg1==0){
										echo "-";
										}
										else{
										echo $jmpg1;
										}
									?>
								</td>
								<td><?php
									$mpg2=mysql_query("SELECT * FROM tb_mutasi WHERE jns_mutasi='Pindah Antar Instansi' AND tgl_mutasi LIKE '$skrg%' AND gol LIKE 'II/%'");
									$jmpg2=mysql_num_rows($mpg2);
										if ($jmpg2==0){
										echo "-";
										}
										else{
										echo $jmpg2;
										}
									?>
								</td>
								<td><?php
									$mpg3=mysql_query("SELECT * FROM tb_mutasi WHERE jns_mutasi='Pindah Antar Instansi' AND tgl_mutasi LIKE '$skrg%' AND gol LIKE 'III/%'");
									$jmpg3=mysql_num_rows($mpg3);
										if ($jmpg3==0){
										echo "-";
										}
										else{
										echo $jmpg3;
										}
									?>
								</td>
								<td><?php
									$mpg4=mysql_query("SELECT * FROM tb_mutasi WHERE jns_mutasi='Pindah Antar Instansi' AND tgl_mutasi LIKE '$skrg%' AND gol LIKE 'IV/%'");
									$jmpg4=mysql_num_rows($mpg4);
										if ($jmpg4==0){
										echo "-";
										}
										else{
										echo $jmpg4;
										}
									?>
								</td>
								<td><?php
									$mpg=mysql_query("SELECT * FROM tb_mutasi WHERE jns_mutasi='Pindah Antar Instansi' AND tgl_mutasi LIKE '$skrg%'");
									$jmpg=mysql_num_rows($mpg);
										if ($jmpg==0){
										echo "-";
										}
										else{
										echo $jmpg;
										}
									?>
								</td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<td></td>
								<td>- PENSIUN</td>
								<td><?php
									$mpng1=mysql_query("SELECT * FROM tb_mutasi WHERE jns_mutasi='Pensiun' AND tgl_mutasi LIKE '$skrg%' AND gol LIKE 'I/%'");
									$jmpng1=mysql_num_rows($mpng1);
										if ($jmpng1==0){
										echo "-";
										}
										else{
										echo $jmpng1;
										}
									?>
								</td>
								<td><?php
									$mpng2=mysql_query("SELECT * FROM tb_mutasi WHERE jns_mutasi='Pensiun' AND tgl_mutasi LIKE '$skrg%' AND gol LIKE 'II/%'");
									$jmpng2=mysql_num_rows($mpng2);
										if ($jmpng2==0){
										echo "-";
										}
										else{
										echo $jmpng2;
										}
									?>
								</td>
								<td><?php
									$mpng3=mysql_query("SELECT * FROM tb_mutasi WHERE jns_mutasi='Pensiun' AND tgl_mutasi LIKE '$skrg%' AND gol LIKE 'III/%'");
									$jmpng3=mysql_num_rows($mpng3);
										if ($jmpng3==0){
										echo "-";
										}
										else{
										echo $jmpng3;
										}
									?>
								</td>
								<td><?php
									$mpng4=mysql_query("SELECT * FROM tb_mutasi WHERE jns_mutasi='Pensiun' AND tgl_mutasi LIKE '$skrg%' AND gol LIKE 'IV/%'");
									$jmpng4=mysql_num_rows($mpng4);
										if ($jmpng4==0){
										echo "-";
										}
										else{
										echo $jmpng4;
										}
									?>
								</td>
								<td><?php
									$mpng=mysql_query("SELECT * FROM tb_mutasi WHERE jns_mutasi='Pensiun' AND tgl_mutasi LIKE '$skrg%'");
									$jmpng=mysql_num_rows($mpng);
										if ($jmpng==0){
										echo "-";
										}
										else{
										echo $jmpng;
										}
									?>
								</td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<td></td>
								<td>- WAFAT</td>
								<td><?php
									$mwafg1=mysql_query("SELECT * FROM tb_mutasi WHERE jns_mutasi='Wafat' AND tgl_mutasi LIKE '$skrg%' AND gol LIKE 'I/%'");
									$jmwafg1=mysql_num_rows($mwafg1);
										if ($jmwafg1==0){
										echo "-";
										}
										else{
										echo $jmwafg1;
										}
									?>
								</td>
								<td><?php
									$mwafg2=mysql_query("SELECT * FROM tb_mutasi WHERE jns_mutasi='Wafat' AND tgl_mutasi LIKE '$skrg%' AND gol LIKE 'II/%'");
									$jmwafg2=mysql_num_rows($mwafg2);
										if ($jmwafg2==0){
										echo "-";
										}
										else{
										echo $jmwafg2;
										}
									?>
								</td>
								<td><?php
									$mwafg3=mysql_query("SELECT * FROM tb_mutasi WHERE jns_mutasi='Wafat' AND tgl_mutasi LIKE '$skrg%' AND gol LIKE 'III/%'");
									$jmwafg3=mysql_num_rows($mwafg3);
										if ($jmwafg3==0){
										echo "-";
										}
										else{
										echo $jmwafg3;
										}
									?>
								</td>
								<td><?php
									$mwafg4=mysql_query("SELECT * FROM tb_mutasi WHERE jns_mutasi='Wafat' AND tgl_mutasi LIKE '$skrg%' AND gol LIKE 'IV/%'");
									$jmwafg4=mysql_num_rows($mwafg4);
										if ($jmwafg4==0){
										echo "-";
										}
										else{
										echo $jmwafg4;
										}
									?>
								</td>
								<td><?php
									$mwafg=mysql_query("SELECT * FROM tb_mutasi WHERE jns_mutasi='Wafat' AND tgl_mutasi LIKE '$skrg%'");
									$jmwafg=mysql_num_rows($mwafg);
										if ($jmwafg==0){
										echo "-";
										}
										else{
										echo $jmwafg;
										}
									?>
								</td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<td></td>
								<td>- KENAIKAN PANGKAT</td>
								<td><?php
									$mnaikg1=mysql_query("SELECT * FROM tb_mutasi WHERE jns_mutasi='Kenaikan Pangkat' AND tgl_mutasi LIKE '$skrg%' AND gol LIKE 'I/%'");
									$jmnaikg1=mysql_num_rows($mnaikg1);
										if ($jmnaikg1==0){
										echo "-";
										}
										else{
										echo $jmnaikg1;
										}
									?>
								</td>
								<td><?php
									$mnaikg2=mysql_query("SELECT * FROM tb_mutasi WHERE jns_mutasi='Kenaikan Pangkat' AND tgl_mutasi LIKE '$skrg%' AND gol LIKE 'II/%'");
									$jmnaikg2=mysql_num_rows($mnaikg2);
										if ($jmnaikg2==0){
										echo "-";
										}
										else{
										echo $jmnaikg2;
										}
									?>
								</td>
								<td><?php
									$mnaikg3=mysql_query("SELECT * FROM tb_mutasi WHERE jns_mutasi='Kenaikan Pangkat' AND tgl_mutasi LIKE '$skrg%' AND gol LIKE 'III/%'");
									$jmnaikg3=mysql_num_rows($mnaikg3);
										if ($jmnaikg3==0){
										echo "-";
										}
										else{
										echo $jmnaikg3;
										}
									?>
								</td>
								<td><?php
									$mnaikg4=mysql_query("SELECT * FROM tb_mutasi WHERE jns_mutasi='Kenaikan Pangkat' AND tgl_mutasi LIKE '$skrg%' AND gol LIKE 'IV/%'");
									$jmnaikg4=mysql_num_rows($mnaikg4);
										if ($jmnaikg4==0){
										echo "-";
										}
										else{
										echo $jmnaikg4;
										}
									?>
								</td>
								<td><?php
									$mnaikg=mysql_query("SELECT * FROM tb_mutasi WHERE jns_mutasi='Kenaikan Pangkat' AND tgl_mutasi LIKE '$skrg%'");
									$jmnaikg=mysql_num_rows($mnaikg);
										if ($jmnaikg==0){
										echo "-";
										}
										else{
										echo $jmnaikg;
										}
									?>
								</td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<td>4</td>
								<td>JENIS HUKUMAN DISIPLIN</td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<td></td>
								<td>- TEGURAN LISAN</td>
								<td><?php
									$hlisg1=mysql_query("SELECT * FROM tb_hukuman WHERE hukuman='Teguran Lisan' AND tgl_sk LIKE '$skrg%' AND gol LIKE 'I/%'");
									$jhlisg1=mysql_num_rows($hlisg1);
										if ($jhlisg1==0){
										echo "-";
										}
										else{
										echo $jhlisg1;
										}
									?>
								</td>
								<td><?php
									$hlisg2=mysql_query("SELECT * FROM tb_hukuman WHERE hukuman='Teguran Lisan' AND tgl_sk LIKE '$skrg%' AND gol LIKE 'II/%'");
									$jhlisg2=mysql_num_rows($hlisg2);
										if ($jhlisg2==0){
										echo "-";
										}
										else{
										echo $jhlisg2;
										}
									?>
								</td>
								<td><?php
									$hlisg3=mysql_query("SELECT * FROM tb_hukuman WHERE hukuman='Teguran Lisan' AND tgl_sk LIKE '$skrg%' AND gol LIKE 'III/%'");
									$jhlisg3=mysql_num_rows($hlisg3);
										if ($jhlisg3==0){
										echo "-";
										}
										else{
										echo $jhlisg3;
										}
									?>
								</td>
								<td><?php
									$hlisg4=mysql_query("SELECT * FROM tb_hukuman WHERE hukuman='Teguran Lisan' AND tgl_sk LIKE '$skrg%' AND gol LIKE 'IV/%'");
									$jhlisg4=mysql_num_rows($hlisg4);
										if ($jhlisg4==0){
										echo "-";
										}
										else{
										echo $jhlisg4;
										}
									?>
								</td>
								<td><?php
									$hlisg=mysql_query("SELECT * FROM tb_hukuman WHERE hukuman='Teguran Lisan' AND tgl_sk LIKE '$skrg%'");
									$jhlisg=mysql_num_rows($hlisg);
										if ($jhlisg==0){
										echo "-";
										}
										else{
										echo $jhlisg;
										}
									?>
								</td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<td></td>
								<td>- TEGURAN TERTULIS</td>
								<td><?php
									$hterg1=mysql_query("SELECT * FROM tb_hukuman WHERE hukuman='Teguran Tertulis' AND tgl_sk LIKE '$skrg%' AND gol LIKE 'I/%'");
									$jhterg1=mysql_num_rows($hterg1);
										if ($jhterg1==0){
										echo "-";
										}
										else{
										echo $jhterg1;
										}
									?>
								</td>
								<td><?php
									$hterg2=mysql_query("SELECT * FROM tb_hukuman WHERE hukuman='Teguran Tertulis' AND tgl_sk LIKE '$skrg%' AND gol LIKE 'II/%'");
									$jhterg2=mysql_num_rows($hterg2);
										if ($jhterg2==0){
										echo "-";
										}
										else{
										echo $jhterg2;
										}
									?>
								</td>
								<td><?php
									$hterg3=mysql_query("SELECT * FROM tb_hukuman WHERE hukuman='Teguran Tertulis' AND tgl_sk LIKE '$skrg%' AND gol LIKE 'III/%'");
									$jhterg3=mysql_num_rows($hterg3);
										if ($jhterg3==0){
										echo "-";
										}
										else{
										echo $jhterg3;
										}
									?>
								</td>
								<td><?php
									$hterg4=mysql_query("SELECT * FROM tb_hukuman WHERE hukuman='Teguran Tertulis' AND tgl_sk LIKE '$skrg%' AND gol LIKE 'IV/%'");
									$jhterg4=mysql_num_rows($hterg4);
										if ($jhterg4==0){
										echo "-";
										}
										else{
										echo $jhterg4;
										}
									?>
								</td>
								<td><?php
									$hterg=mysql_query("SELECT * FROM tb_hukuman WHERE hukuman='Teguran Tertulis' AND tgl_sk LIKE '$skrg%'");
									$jhterg=mysql_num_rows($hterg);
										if ($jhterg==0){
										echo "-";
										}
										else{
										echo $jhterg;
										}
									?>
								</td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<td></td>
								<td>- TUNDA KENAIKAN BERKALA</td>
								<td><?php
									$hberg1=mysql_query("SELECT * FROM tb_hukuman WHERE hukuman='Tunda Kenaikan Berkala' AND tgl_sk LIKE '$skrg%' AND gol LIKE 'I/%'");
									$jhberg1=mysql_num_rows($hberg1);
										if ($jhberg1==0){
										echo "-";
										}
										else{
										echo $jhberg1;
										}
									?>
								</td>
								<td><?php
									$hberg2=mysql_query("SELECT * FROM tb_hukuman WHERE hukuman='Tunda Kenaikan Berkala' AND tgl_sk LIKE '$skrg%' AND gol LIKE 'II/%'");
									$jhberg2=mysql_num_rows($hberg2);
										if ($jhberg2==0){
										echo "-";
										}
										else{
										echo $jhberg2;
										}
									?>
								</td>
								<td><?php
									$hberg3=mysql_query("SELECT * FROM tb_hukuman WHERE hukuman='Tunda Kenaikan Berkala' AND tgl_sk LIKE '$skrg%' AND gol LIKE 'III/%'");
									$jhberg3=mysql_num_rows($hberg3);
										if ($jhberg3==0){
										echo "-";
										}
										else{
										echo $jhberg3;
										}
									?>
								</td>
								<td><?php
									$hberg4=mysql_query("SELECT * FROM tb_hukuman WHERE hukuman='Tunda Kenaikan Berkala' AND tgl_sk LIKE '$skrg%' AND gol LIKE 'IV/%'");
									$jhberg4=mysql_num_rows($hberg4);
										if ($jhberg4==0){
										echo "-";
										}
										else{
										echo $jhberg4;
										}
									?>
								</td>
								<td><?php
									$hberg=mysql_query("SELECT * FROM tb_hukuman WHERE hukuman='Tunda Kenaikan Berkala' AND tgl_sk LIKE '$skrg%'");
									$jhberg=mysql_num_rows($hberg);
										if ($jhberg==0){
										echo "-";
										}
										else{
										echo $jhberg;
										}
									?>
								</td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<td></td>
								<td>- TUNDA KENAIKAN PANGKAT</td>
								<td><?php
									$hpg1=mysql_query("SELECT * FROM tb_hukuman WHERE hukuman='Tunda Kenaikan Pangkat' AND tgl_sk LIKE '$skrg%' AND gol LIKE 'I/%'");
									$jhpg1=mysql_num_rows($hpg1);
										if ($jhpg1==0){
										echo "-";
										}
										else{
										echo $jhpg1;
										}
									?>
								</td>
								<td><?php
									$hpg2=mysql_query("SELECT * FROM tb_hukuman WHERE hukuman='Tunda Kenaikan Pangkat' AND tgl_sk LIKE '$skrg%' AND gol LIKE 'II/%'");
									$jhpg2=mysql_num_rows($hpg2);
										if ($jhpg2==0){
										echo "-";
										}
										else{
										echo $jhpg2;
										}
									?>
								</td>
								<td><?php
									$hpg3=mysql_query("SELECT * FROM tb_hukuman WHERE hukuman='Tunda Kenaikan Pangkat' AND tgl_sk LIKE '$skrg%' AND gol LIKE 'III/%'");
									$jhpg3=mysql_num_rows($hpg3);
										if ($jhpg3==0){
										echo "-";
										}
										else{
										echo $jhpg3;
										}
									?>
								</td>
								<td><?php
									$hpg4=mysql_query("SELECT * FROM tb_hukuman WHERE hukuman='Tunda Kenaikan Pangkat' AND tgl_sk LIKE '$skrg%' AND gol LIKE 'IV/%'");
									$jhpg4=mysql_num_rows($hpg4);
										if ($jhpg4==0){
										echo "-";
										}
										else{
										echo $jhpg4;
										}
									?>
								</td>
								<td><?php
									$hpg=mysql_query("SELECT * FROM tb_hukuman WHERE hukuman='Tunda Kenaikan Pangkat' AND tgl_sk LIKE '$skrg%'");
									$jhpg=mysql_num_rows($hpg);
										if ($jhpg==0){
										echo "-";
										}
										else{
										echo $jhpg;
										}
									?>
								</td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<td></td>
								<td>- PEMBERHENTIAN</td>
								<td><?php
									$hpemg1=mysql_query("SELECT * FROM tb_hukuman WHERE hukuman='Pemberhentian' AND tgl_sk LIKE '$skrg%' AND gol LIKE 'I/%'");
									$jhpemg1=mysql_num_rows($hpemg1);
										if ($jhpemg1==0){
										echo "-";
										}
										else{
										echo $jhpemg1;
										}
									?>
								</td>
								<td><?php
									$hpemg2=mysql_query("SELECT * FROM tb_hukuman WHERE hukuman='Pemberhentian' AND tgl_sk LIKE '$skrg%' AND gol LIKE 'II/%'");
									$jhpemg2=mysql_num_rows($hpemg2);
										if ($jhpemg2==0){
										echo "-";
										}
										else{
										echo $jhpemg2;
										}
									?>
								</td>
								<td><?php
									$hpemg3=mysql_query("SELECT * FROM tb_hukuman WHERE hukuman='Pemberhentian' AND tgl_sk LIKE '$skrg%' AND gol LIKE 'III/%'");
									$jhpemg3=mysql_num_rows($hpemg3);
										if ($jhpemg3==0){
										echo "-";
										}
										else{
										echo $jhpemg3;
										}
									?>
								</td>
								<td><?php
									$hpemg4=mysql_query("SELECT * FROM tb_hukuman WHERE hukuman='Pemberhentian' AND tgl_sk LIKE '$skrg%' AND gol LIKE 'IV/%'");
									$jhpemg4=mysql_num_rows($hpemg4);
										if ($jhpemg4==0){
										echo "-";
										}
										else{
										echo $jhpemg4;
										}
									?>
								</td>
								<td><?php
									$hpemg=mysql_query("SELECT * FROM tb_hukuman WHERE hukuman='Pemberhentian' AND tgl_sk LIKE '$skrg%'");
									$jhpemg=mysql_num_rows($hpemg);
										if ($jhpemg==0){
										echo "-";
										}
										else{
										echo $jhpemg;
										}
									?>
								</td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<td>5</td>
								<td>JUMLAH PTT</td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td><?php
									$ptt=mysql_query("SELECT * FROM tb_pegawai WHERE status_kepeg='PTT'");
									$jptt=mysql_num_rows($ptt);
										if ($jptt==0){
										echo "-";
										}
										else{
										echo $jptt;
										}
									?>				
								</td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<td></td>
								<td>- PRIA</td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td><?php
									$pttl=mysql_query("SELECT * FROM tb_pegawai WHERE status_kepeg='PTT' AND jk='Laki-laki'");
									$jpttl=mysql_num_rows($pttl);
										if ($jpttl==0){
										echo "-";
										}
										else{
										echo $jpttl;
										}
									?>				
								</td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<td></td>
								<td>- WANITA</td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td><?php
									$pttp=mysql_query("SELECT * FROM tb_pegawai WHERE status_kepeg='PTT' AND jk='Perempuan'");
									$jpttp=mysql_num_rows($pttp);
										if ($jpttp==0){
										echo "-";
										}
										else{
										echo $jpttp;
										}
									?>				
								</td>
								<td></td>
								<td></td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</section>