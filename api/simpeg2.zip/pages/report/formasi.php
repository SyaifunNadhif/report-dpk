<section class="content-header">
    <h1>Report<small>Formasi Pegawai</small></h1>
    <ol class="breadcrumb">
        <li><a href="home-admin.php"><i class="fa fa-dashboard"></i>Dashboard</a></li>
        <li class="active">Formasi Pegawai</li>
    </ol>
</section>
<section class="content">
	<div class="row">
		<div class="col-md-12">	
			<div class="box box-primary">
				<div class="box-body" align="right">						
					<a type="button" href="./pages/report/print-bezetting.php" target="_blank" class="btn btn-default bg-orange"><i class="fa fa-print"></i> Print</a>						
				</div>
				<div class="box-body">
					<h4 class="title" align="center">DAFTAR FORMASI PEGAWAI</h4>
					<h5 class="title" align="center">PADA BPR BKK JATENG PERIODE BULAN <?php echo date ("m");?> TAHUN <?php echo date ("Y");?></h5>
					<table class="col-sm-12 table table-bordered table-hover">
						<thead>
							<tr>
								<th>No</th>
								<th>NAMA<br />TEMPAT TANGGAL LAHIR</th>
								<th>NIP</th>
								<th>PANGKAT<br />GOL/RUANG</th>
								<th>JABATAN</th>
								<th>PENDIDIKAN<br />TERAKHIR</th>
								<th>UMUR (THN)</th>
								<th>KET</th>
							</tr>
							<tr>
								<th>1</th>
								<th>2</th>
								<th>3</th>
								<th>4</th>
								<th>5</th>
								<th>6</th>
								<th>7</th>
								<th>8</th>
							</tr>
						</thead>
						<tbody>
							<?php
							include "dist/koneksi.php";
							$no=0;
							$idPeg=mysql_query("SELECT * FROM tb_pegawai WHERE status_kepeg='PNS' ORDER BY urut_pangkat DESC");
							while($peg=mysql_fetch_array($idPeg)){
							$no++
							?>
							<tr>
								<td><?=$no;?></td>
								<td><?php echo $peg['nama']; ?><br /><?php echo $peg['tempat_lhr']; ?>, <?php echo $peg['tgl_lhr']; ?></td>
								<td><?php echo $peg['nip']; ?></td>
								<td><?php
									$idPan=mysql_query("SELECT * FROM tb_pangkat WHERE (id_peg='$peg[id_peg]' AND status_pan='Aktif')");
									$hpan=mysql_fetch_array($idPan);
								?>
								<?php echo $hpan['pangkat']; ?><br /><?php echo $hpan['gol']; ?></td>
								<td><?php
									$idJab=mysql_query("SELECT * FROM tb_jabatan WHERE (id_peg='$peg[id_peg]' AND status_jab='Aktif')");
									$hjab=mysql_fetch_array($idJab);
								?>
								<?php echo $hjab['jabatan']; ?></td>
								<td><?php
									$idSek=mysql_query("SELECT * FROM tb_sekolah WHERE (id_peg='$peg[id_peg]' AND status='Akhir')");
									$hsek=mysql_fetch_array($idSek);
								?>
								<?php echo $hsek['tingkat']; ?>
								</td>
								<td><?php
									$lhr	= new DateTime($peg['tgl_lhr']);
									$today	= new DateTime();										
									$selisih	= $today->diff($lhr);										
										echo $selisih->y;
									?>											
								</td>
								<td><?php echo $peg['status_kepeg']; ?></td>
							</tr>
							<?php
							}		
							?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</section>